/*
 * Util.h
 *
 *  Created on: Nov 10, 2018
 *      Author: 1828B
 */

#ifndef UTIL_H_
#define UTIL_H_

namespace Util
{
	double Limit(double upperlimit, double lowerlimit, double value );
}



#endif /* UTIL_H_ */
