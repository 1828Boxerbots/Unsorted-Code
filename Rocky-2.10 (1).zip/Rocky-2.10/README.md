# Rocky
A repository for the robot Rocky from the 1828 BoxerBots game year 2012. The following code is a rewrtitten version in C++ using the 2017-2018 WPI Library's functions.
