/*
 * Util.h
 *
 *  Created on: Jan 10, 2018
 *      Author: Science Center 3
 */

#ifndef UTIL_H_
#define UTIL_H_

namespace util
{
	double Limit(double upperLimit, double lowerLimit, double value);
}

#endif /* UTIL_H_ */
